<!DOCTYPE html>
<html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>
    <?php echo htmlspecialchars($this->Setting_Model->get('meta_title')); ?>
  </title>
  <meta name="description" content="<?php echo htmlspecialchars($this->Setting_Model->get('meta_description')); ?>">
  <meta name="keywords" content="<?php echo htmlspecialchars($this->Setting_Model->get('meta_keywords')); ?>" />
  <meta name="author" content="<?php echo htmlspecialchars($this->Setting_Model->get('meta_author')); ?>">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="canonical" href="https://www.kokorosushi.be" />

  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes"> 
  

  <!-- ==============OG=================== -->
  <meta property="og:title" content="Sushi Mol Kokoro - Bestel Online Official">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://kokorosushi.be/">
  <meta property="og:image" content="https://kokorosushi.be/assets/images/sushi_mol.png">
  <meta property="og:description" content="Beste Sushi Mol, heerlijke sushi gerechten zijn sushi combo's, broodjes en nigiri met saus. afhalen, Take Away">
  <meta property="og:site_name" content="Kokorosushi">
  <!-- ==============OG=================== -->
  
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/idea_style.css">
  <!-- <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/idea_style2.css"> -->
  <!-- <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/idea_style3.css"> -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
    integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/animate.min.css">
  <!-- Favicon -->
  <link rel="apple-touch-icon" sizes="57x57" href="<?php echo base_url(); ?>assets/images/favicon/apple-icon-57x57.png">
  <link rel="apple-touch-icon" sizes="60x60" href="<?php echo base_url(); ?>assets/images/favicon/apple-icon-60x60.png">
  <link rel="apple-touch-icon" sizes="72x72" href="<?php echo base_url(); ?>assets/images/favicon/apple-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url(); ?>assets/images/favicon/apple-icon-76x76.png">
  <link rel="apple-touch-icon" sizes="114x114"
    href="<?php echo base_url(); ?>assets/images/favicon/apple-icon-114x114.png">
  <link rel="apple-touch-icon" sizes="120x120"
    href="<?php echo base_url(); ?>assets/images/favicon/apple-icon-120x120.png">
  <link rel="apple-touch-icon" sizes="144x144"
    href="<?php echo base_url(); ?>assets/images/favicon/apple-icon-144x144.png">
  <link rel="apple-touch-icon" sizes="152x152"
    href="<?php echo base_url(); ?>assets/images/favicon/apple-icon-152x152.png">
  <link rel="apple-touch-icon" sizes="180x180"
    href="<?php echo base_url(); ?>assets/images/favicon/apple-icon-180x180.png">
  <link rel="icon" type="image/png" sizes="192x192"
    href="<?php echo base_url(); ?>assets/images/favicon/android-icon-192x192.png">
  <link rel="icon" type="image/png" sizes="144x144"
    href="<?php echo base_url(); ?>assets/images/favicon/android-icon-144x144.png">
  <link rel="icon" type="image/png" sizes="32x32"
    href="<?php echo base_url(); ?>assets/images/favicon/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="96x96"
    href="<?php echo base_url(); ?>assets/images/favicon/favicon-96x96.png">
  <link rel="icon" type="image/png" sizes="16x16"
    href="<?php echo base_url(); ?>assets/images/favicon/favicon-16x16.png">
  <link rel="manifest" href="<?php echo base_url(); ?>assets/images/favicon/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="<?php echo base_url(); ?>assets/images/favicon/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">
  <script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>

  <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">

  <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

  <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Corporation",
  "name": "Sushi Mol Kokoro",
  "alternateName": "Sushi Mol",
  "url": "https://kokorosushi.be",
  "logo": "https://kokorosushi.be/assets/images/sushi_mol.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+32 14872578",
    "contactType": "customer service",
    "areaServed": "BE",
    "availableLanguage": ["en","Dutch"]
  },
  "sameAs": [
    "https://www.facebook.com/KokorosushiBentoMol",
    "https://www.takeaway.com/be-en/menu/kokoro-sushi",
    "https://www.instagram.com/kokorosushi21"
  ]
}
</script>

  <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Restaurant",
  "name": "Sushi Mol",
  "image": "https://kokorosushi.be/assets/images/sushi_mol.png",
  "@id": "https://kokorosushi.be/",
  "url": "https://kokorosushi.be",
  "telephone": "+32 14 872 578",
  "menu": "https://kokorosushi.be",
  "servesCuisine": "VOORGERECHTEN, CRISPY ROLL, Sushi COMBO, Sushi BOX, Sushi BOAT, NIGIRI & SASHIMI, KIDS MENU, POKE BOWL & SHIRAISHI, SOUP, DONBURI, NOEDELS, UDON, CALIFORNIA ROLL, HANDROLL TEMAKI, RICE PAPER, SASHIMI ROLL, GREEN SPRING ROLL, NIGIRI & GUNKAN KOUDE",
  "acceptsReservations": "true",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "CORBIESTRAAT 21",
    "addressLocality": "Mol",
    "postalCode": "2400",
    "addressCountry": "BE"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 51.18681092091911,
    "longitude": 5.117387324884575
  } ,
  "sameAs": [
    "https://www.facebook.com/KokorosushiBentoMol",
    "https://www.instagram.com/kokorosushi21"
  ] 
}
</script>

  <script type="application/ld+json">
{
  "@context": "https://schema.org/", 
  "@type": "BreadcrumbList", 
  "itemListElement": [{
    "@type": "ListItem", 
    "position": 1, 
    "name": "VOORGERECHTEN",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 2, 
    "name": "CRISPY ROLL",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 3, 
    "name": "COMBO/BOX/BOAT",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 4, 
    "name": "NIGIRI & SASHIMI COMBO",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 5, 
    "name": "KIDS MENU",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 6, 
    "name": "POKE BOWL & SHIRAISHI",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 7, 
    "name": "SOUP, DONBURI, NOEDELS, UDON",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 8, 
    "name": "CALIFORNIA ROLL",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 9, 
    "name": "CHEF ROLL /SPECIAAL",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 10, 
    "name": "MEGA - LUX ROLL",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 11, 
    "name": "HOSOMAKI",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 12, 
    "name": "HANDROLL TEMAKI",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 13, 
    "name": "RICE PAPER SASHIMI ROLL",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 14, 
    "name": "GREEN SPRING ROLL",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 15, 
    "name": "NIGIRI & GUNKAN",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 16, 
    "name": "KOUDE DRANKEN",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 17, 
    "name": "WARME DRANKEN",
    "item": "https://kokorosushi.be/"  
  },{
    "@type": "ListItem", 
    "position": 18, 
    "name": "DESSERTS",
    "item": "https://kokorosushi.be/"  
  }]
}
</script>

  <style>

    .link{
      color: #FE4545;
    }

    #btn-back-to-top {
      position: fixed;
      display: none;
    }


    /* back to top css start */

    #back2Top {
      width: 50px;
      height: 50px;
      overflow: hidden;
      z-index: 999;
      display: none;
      cursor: pointer;
      position: fixed;
      bottom: 150px;
      right: 5px;
      text-align: center;
      font-size: 30px;
      text-decoration: none;
      border-radius: 50%;
      transition: 0.5s;
    
    }

  #back2Top:hover .icon{
  animation: anim 0.5s linear 0s 1 ;
  }

  @keyframes anim {
  0%{
    transform: translateY(0rem);
    opacity: 1;
  }
  48%{
    transform: translateY(-3rem);
    opacity: 1;
    
  }
  49%{
    transform: translateY(3rem);
    opacity: 0;
    color: #dcb14a;
  }
  50%{
    transform: translateY(3rem);
    opacity: 0;
    color: white;
  }
  100%{
    transform: translateY(0rem);
  }
  
}







    /* back to top css end */



    /* video style   */

    @import "compass/css3";

@import url(https://fonts.googleapis.com/css?family=Oswald:300);
* { box-sizing: border-box; }

video { border-radius: 6px; }

/* video container */
.videoContainer{
	width:330px;
	height:163px;
	position:relative;
	overflow:hidden;
	background:#000;
	color:#ccc;
	border-radius: 6px;
	border: 1px dashed rgba(0,0,0,0.5);
	box-shadow: 0 0 5px rgba(0,0,0,0.5);
	margin: 50px auto 0;
}
.videoContainer:before {
	content: '';
	position: absolute;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	box-shadow: inset 0 1px 2px rgba(255,255,255,0.3);
	z-index: 6;
	border-radius: 6px;
	pointer-events: none;
}

/* video caption css */
.caption{
	display:none;
	position:absolute;
	top:0;
	left:0;
	width:100%;
	padding: 5px 10px;
	color:#ddd;
	font-size:14px;
	font-weight:300;
	text-align: center;
	background: rgba(0,0,0,0.4);
	text-transform: uppercase;
	border-radius: 6px 6px 0 0;
	-webkit-backface-visibility: hidden;
  -moz-backface-visibility:    hidden;
  -ms-backface-visibility:     hidden;
}

/*** VIDEO CONTROLS CSS ***/
/* control holder */
.control{
	color:#ccc;
	position:absolute;
	bottom:10px;
	left:10px;
	width:360px;
	z-index:5;
	display:none;
}
/* control bottom part */
.btmControl{
	clear:both;
}
.control .btnPlay {
	float:left;
	width:34px;
	height:30px;
	padding:5px;
	background: rgba(0,0,0,0.5);
	cursor:pointer;
	border-radius: 6px 0 0 6px;
	border: 1px solid rgba(0,0,0,0.7);
	box-shadow: inset 0 0 1px rgba(255,255,255,0.5);
}
.control .icon-play{
	background:url(https://s.cdpn.io/6035/vp_sprite.png) no-repeat -11px 0;
	width: 6px;
	height: 9px;
	display: block;
	margin: 4px 0 0 8px;
}
.control .icon-pause{
	background:url(https://s.cdpn.io/6035/vp_sprite.png) no-repeat -34px -1px;
	width: 8px;
	height: 9px;
	display: block;
	margin: 4px 0 0 8px;
}
.control .selected{
	font-size:15px;
	color:#ccc;
}
.control .sound{
	width: 30px;
	height: 30px;
	float:left;
	background: rgba(0,0,0,0.5);
  
	border: 1px solid rgba(0,0,0,0.7);
	border-left: none;
	box-shadow: inset 0 0 1px rgba(255,255,255,0.5);
	cursor: pointer;
}
.control .icon-sound {  
	background:url(https://s.cdpn.io/6035/vp_sprite.png) no-repeat -19px 0;
	width: 13px;
	height: 10px;
	display: block;
	margin: 8px 0 0 8px;
}
.control .muted .icon-sound{
	width: 7px !important;
}
.control .btnFS{
	width: 30px;
	height: 30px;
	border-radius: 0 6px 6px 0;
	float:left;
	background: rgba(0,0,0,0.5);
	border: 1px solid rgba(0,0,0,0.7);
	border-left: none;
	box-shadow: inset 0 0 1px rgba(255,255,255,0.5);

}
.control .icon-fullscreen {  
	background:url(https://s.cdpn.io/6035/vp_sprite.png) no-repeat 0 0;
	width: 10px;
	height: 10px;
	display: block;
	margin: 8px 0 0 9px;
}

/* PROGRESS BAR CSS */
/* Progress bar */
.progress-bar {
	height: 30px;
	padding: 10px;
	background: rgba(0,0,0,0.6);
	border: 1px solid rgba(0,0,0,0.7);
	border-left: none;
	box-shadow: inset 0 0 1px rgba(255,255,255,0.5);
	float:left;

}
.progress {
	width:200px;
	height:7px;
	position:relative;
	cursor:pointer;
	background: rgba(0,0,0,0.4); /* fallback */
	box-shadow: 0 1px 0 rgba(255,255,255,0.1), inset 0 1px 1px rgba(0,0,0,1);
	border-radius:10px;
}
.progress span {
	height:100%;
	position:absolute;
	top:0;
	left:0;
	display:block;
	border-radius:10px;
}
.timeBar{
	z-index:10;
	width:0;
	background: -webkit-linear-gradient(top, rgba(107,204,226,1) 0%,rgba(29,163,208,1) 100%);
	box-shadow: 0 0 7px rgba(107,204,226,.5);
}
.bufferBar{
	z-index:5;
	width:0;
	background: rgba(255,255,255,0.2);
}

/* VOLUME BAR CSS */
/* volume bar */
.volume{
	position:relative;
	cursor:pointer;
	width:70px;
	height:10px;
	float:right;
	margin-top:10px;
	margin-right:10px;
}
.volumeBar{
	display:block;
	height:100%;
	position:absolute;
	top:0;
	left:0;
	background-color:#eee;
	z-index:10;
}



  </style>
</head>
<div class="preloader">
  <div class="heart"></div>
</div>

<body class="">
  <div id="full_width" class="font-segoe bg-white website scroll-smooth">
    <div class="grid grid-cols-6 justify-evenly bg-[#ea2227] text-white py-[2px] text-sm font-medium">
      <div class="sm:col-span-3 col-span-6 text-[11px] font-light" style="text-align: center">
        <a style="color: #ffffff;" href="callto:+3214872578">
          <h2> <i class="fa fa-phone">&nbsp; + 32 14 872 578</i> </h2>
        </a>
      </div>
      <div class="sm:col-span-3 col-span-6 sm:mt-0 mt-1 flex justify-center" style="text-align: center">
        <span style="color: #ffffff;" class="mr-5">
          <h2> <i class="fa fa-map-marker-alt"></i> &nbsp;Corbiestraat 21 - 2400 Mol, Belgium </h2>
        </span>

      </div>
    </div>
    <!-- success -->
    <?php if ($this->session->flashdata('success') != ""): ?>
      <div id="success_msg" class="fadeIn fixed top-[0%] w-[-webkit-fill-available] z-20">
        <div
          class="h-screen flex items-center justify-center w-10/12 sm:w-8/12 md:w-7/12 lg:w-6/12 mx-auto drop-shadow-2xl">
          <div class="text-center bg-gray-100 py-2 px-3 sm:py-3 sm:px-6 rounded-2xl shadow-gray-300   shadow-inner">
            <div class="text-4xl font-bold text-green-700">
              success!
            </div>
            <hr class="my-[12px]">
            <div class="text-lg font-normal text-gray-800">
              <div class="leading-[24px]">
                <!-- your order has been placed successfully,<br>we will contact you soon. -->
                <?php echo $this->session->flashdata('success'); ?>
              </div>
              <div class="my-[12px] text-[#ff3131] font-semibold text-lg">Order number : <?php echo "#" . $this->session->flashdata('order_id'); ?></div>
              <div class="mb-[12px] flex items-center justify-center">
                <div class="text-[14px] md:text-[14px]">Call or WhatsApp us : +3214872578
                  <a target="_blank"
                    href="https://api.whatsapp.com/send?phone=+320484550510&text=Hi%2C+I+placed+an+order+%F0%9F%91%87%0A%0A%F0%9F%9B%B5%F0%9F%94%9C%F0%9F%8F%A1%0A%2ADelivery+Order+No%3A+<?php echo "%23" . $this->session->flashdata('order_id') ?>%2A%0A%0A---------%0A%F0%9F%97%92+Total%3A <?php echo "€" . $this->session->flashdata('total_price'); ?>%0A%F0%9F%9B%B5+Delivery Method%3A <?php echo $this->session->flashdata('method') ?>"
                    class="ml-[10px] cursor-pointer"><i class="fa-brands fa-whatsapp"></i></a>
                </div>
                <!-- <a target="_blank" href="https://api.whatsapp.com/send?phone=+320484550510&text=<?php echo "%23" . $this->session->flashdata('order_id') . ", Price: €" . $this->session->flashdata('total_price'); ?>" class="ml-[10px] cursor-pointer"><i class="fa-brands fa-whatsapp"></i></a> -->

              </div>
            </div>
            <div class="mb-[12px] flex items-center justify-center">
              <button onclick="hide_sucess()"
                class="cursor-default lg:cursor-pointer font-bold text-xl bg-gradient-to-r from-[#fe1e62] via-[#fe5568] to-[#fe8a6d] text-white rounded-2xl px-[25px] py-[2px]">close</button>
            </div>

          </div>
        </div>
      </div>
    <?php endif; ?>
    <!-- success -->

    <!-- navbar -->
    <div class="grid grid-cols-12 m-auto justify-items-center pt-4">

      <div id="nav_ele" class="col-span-12">
        <ul class="space-x-8 font-bold">
          <li class="float-left hover:text-[#fb5b5b] duration-200 cursor-pointer"><a
              href="<?php echo base_url(); ?>">Home</a></li>
          <li class="float-left hover:text-[#fb5b5b] duration-200 cursor-pointer"><a
              href="<?php echo base_url(); ?>about">About</a></li>
          <li class="float-left hover:text-[#fb5b5b] duration-200 cursor-pointer"><a
              href="<?php echo base_url(); ?>chief">Chief</a></li>
          <li class="float-left hover:text-[#fb5b5b] duration-200 cursor-pointer"><a
              href="https://g.page/r/CWkabtmzbkabEAg/review" target="_blank" style="
                display: flex;
            ">Feedback Please<img src="https://www.kokorosushi.be//assets/images/good-sushi-review.svg"
                style="width:100px;margin-left: 6px;"></a></li>
          <!-- <li class="float-left hover:text-[#fb5b5b] duration-200 cursor-pointer"><a href="<?php echo base_url(); ?>contact">Contact</a></li> -->
        </ul>
      </div>
    </div>
    <!-- navbar -->

    <button id="back2Top" title="Back to top" class="bg-red-600 text-white ">
      <svg aria-hidden="true" focusable="false" data-prefix="fas" class="w-4 h-6 mx-auto icon" role="img"
        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
        <path fill="currentColor"
          d="M34.9 289.5l-22.2-22.2c-9.4-9.4-9.4-24.6 0-33.9L207 39c9.4-9.4 24.6-9.4 33.9 0l194.3 194.3c9.4 9.4 9.4 24.6 0 33.9L413 289.4c-9.5 9.5-25 9.3-34.3-.4L264 168.6V456c0 13.3-10.7 24-24 24h-32c-13.3 0-24-10.7-24-24V168.6L69.2 289.1c-9.3 9.8-24.8 10-34.3.4z">
        </path>
      </svg>
    </button>




    <script>
      $(window).scroll(function () {
        var height = $(window).scrollTop();
        if (height > 100) {
          $('#back2Top').fadeIn();
        } else {
          $('#back2Top').fadeOut();
        }
      });
      $(document).ready(function () {
        $("#back2Top").click(function (event) {
          event.preventDefault();
          $("html, body").animate({ scrollTop: 0 }, 2000);
          return false;
        });

      });
    </script>